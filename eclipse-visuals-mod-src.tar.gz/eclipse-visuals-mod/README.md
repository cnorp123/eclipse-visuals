# Eclipse Visuals — Minecraft 1.21.4 Fabric Mod

A feature-rich visual client mod for Minecraft 1.21.4 Fabric.

## Features

**Visuals**: Full Bright, Zoom, Particles, China Hit, Hit Color, Jump Circles, Motion Blur, Arrow Trail, Entity Outline, Block Overlay, Animations, Custom Crosshair

**HUD**: FPS Counter, Keystrokes, Armour HUD, Watermark, Target HUD, Scoreboard, Ping Display, CPS Counter, Combo Counter, Pack Display

**Utilities**: Auto Sprint, Auto-GG, Quick Chat, Nick System, Auto Fish, Auto Reconnect, Free Look

## Keybindings

| Key | Action |
|-----|--------|
| `Right Shift` | Open / close Eclipse Visuals menu |
| `C` | Zoom (hold while Zoom feature is enabled) |

## Building

**Requirements:**
- JDK 21 (https://adoptium.net)
- Gradle (https://gradle.org) OR use the included Gradle wrapper

```bash
# 1. Download Gradle wrapper (first time only)
gradle wrapper --gradle-version 8.8

# 2. Build the mod
./gradlew build
```

The compiled `.jar` will be at:
```
build/libs/eclipse-visuals-1.0.0.jar
```

## Installation

1. Install [Fabric Loader 0.16+](https://fabricmc.net/use/)
2. Install [Fabric API](https://modrinth.com/mod/fabric-api) for 1.21.4
3. Drop `eclipse-visuals-1.0.0.jar` into your `.minecraft/mods/` folder
4. Launch Minecraft 1.21.4 with the Fabric profile

## Config

Config file is saved to `.minecraft/config/eclipse-visuals.json` and is auto-created on first launch.

## License

MIT
